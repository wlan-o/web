export const products = [
  {
    id: 1,
    name:
      "New Apple iPad Air (10.9-inch, Wi-Fi, 64GB) - Sky Blue (Latest Model, 4th Generation)",
    price: 899,
    description:
      "A versatile device for comfortable work, easy content viewing and content creation",
    rating: 4.9,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71cI0vnaLiL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Apple-iPad-Air-10-9-inch-Wi-Fi-64GB/dp/B08J61FCVN/ref=sr_1_1?dchild=1&keywords=ipad&qid=1614630296&sr=8-1"
  },
  {
    id: 2,
    name: "Apple iPad Mini (Wi-Fi, 64GB) - Space Gray (Latest Model)",
    price: 799,
    description:
      "A versatile device for comfortable work, easy content viewing and content creation",
    rating: 4.8,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71Ha06XS-VL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Apple-iPad-Mini-Wi-Fi-64GB/dp/B07PRD2NQ7/ref=sr_1_2?dchild=1&keywords=ipad&qid=1614630296&sr=8-2"
  },
  {
    id: 3,
    name:
      "2020 Apple iPad Pro (12.9-inch, Wi-Fi, 256GB) - Space Gray (4th Generation)",
    price: 1299,
    description:
      "A versatile device for comfortable work, easy content viewing and content creation",
    rating: 4.9,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/81SGb5l%2BlZL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Apple-iPad-12-9-inch-Wi-Fi-256GB/dp/B0862HNWGK/ref=sr_1_3?dchild=1&keywords=ipad&qid=1614630296&sr=8-3"
  },
  {
    id: 4,
    name:
      "Apple Magic Keyboard for iPad Air (4th Generation) and iPad Pro 11-inch (2nd Generation) - US English",
    price: 199,
    description:
      "The all-new Magic Keyboard is an amazing companion for iPad Pro",
    rating: 4.8,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71fYV0JMoYL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Magic-Keyboard-11-inch-iPad-Generation/dp/B0863BQJMS/ref=sr_1_4?dchild=1&keywords=ipad&qid=1614630296&sr=8-4"
  },
  {
    id: 5,
    name:
      "2020 Apple iPad Pro (11-inch, Wi-Fi, 256GB) - Space Gray (2nd Generation)",
    price: 1199,
    description:
      "A versatile device for comfortable work, easy content viewing and content creation",
    rating: 4.9,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/815ztYEEwYL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Apple-iPad-11-inch-Wi-Fi-256GB/dp/B0863358NV/ref=sr_1_5?dchild=1&keywords=ipad&qid=1614630296&sr=8-5"
  },
  {
    id: 6,
    name:
      'SAMSUNG QN32Q50RAFXZA Flat 32" QLED 4K 32Q50 Series Smart TV (2019 model)',
    price: 447,
    description: "Very good TV",
    rating: 4.7,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/51NKhnjhpGL._AC_SL1024_.jpg",
    url:
      "https://www.amazon.com/SAMSUNG-QN32Q50RAFXZA-32Q50-Smart-TV2019/dp/B07W5QYD2K/ref=sr_1_7?dchild=1&field-shipping_option-bin=3242350011&pf_rd_i=16225009011&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=85a9188d-dbd5-424e-9512-339a1227d37c&pf_rd_r=AD29S7280F7DR68TFM15&pf_rd_s=merchandised-search-5&pf_rd_t=101&qid=1614634837&rnid=1266092011&s=electronics&sr=1-7"
  },
  {
    id: 7,
    name: "Monopoly Deal Card Game",
    price: 7.99,
    description:
      "New Monopoly Deal card game that is moving through Family Game Nights everywhere",
    rating: 4.8,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/91KOKqHaKpL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Hasbro-B0965-Monopoly-Deal-Card/dp/B00NQQTZCO/ref=sr_1_8?dchild=1&fst=as%3Aoff&pf_rd_i=16225014011&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=a3460e00-9eac-4cab-9814-093998a3f6d8&pf_rd_r=JXZSTCC3A4FCKXAZQRC2&pf_rd_s=merchandised-search-4&pf_rd_t=101&qid=1614635127&rnid=16225014011&s=sporting-goods&sr=1-8"
  },
  {
    id: 8,
    name: "Spalding NBA Street Outdoor Basketball",
    price: 17.99,
    description: "Basketball ball",
    rating: 4.7,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/91PlxEj64%2BL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Spalding-NBA-Street-Basketball-Official/dp/B0009VELG4/ref=sr_1_17?dchild=1&fst=as%3Aoff&pf_rd_i=16225014011&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=a3460e00-9eac-4cab-9814-093998a3f6d8&pf_rd_r=JXZSTCC3A4FCKXAZQRC2&pf_rd_s=merchandised-search-4&pf_rd_t=101&qid=1614636238&rnid=16225014011&s=sporting-goods&sr=1-17"
  },
  {
    id: 9,
    name: "Nintendo Switch - Mario Red & Blue Edition - Switch",
    price: 375.98,
    description: "Game console",
    rating: 4.9,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71K3XD9oosL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Nintendo-Switch-Mario-Red-Blue/dp/B08M8YQMH4/ref=lp_16225016011_1_5"
  },
  {
    id: 10,
    name:
      "AmazonBasics Low-Back Computer Task Office Desk Chair with Swivel Casters - Blue",
    price: 55.97,
    description:
      "Comfortable task and computer chair with blue contoured mesh back for support and breathability",
    rating: 4.9,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71rpJTFtMgL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/AmazonBasics-Low-Back-Computer-Chair-Blue/dp/B01D7P5NI8/ref=sr_1_7?dchild=1&keywords=amazonbasics&pd_rd_r=0a922aeb-fa4b-48f5-a1a0-8ec74d9b8b19&pd_rd_w=e0h4J&pd_rd_wg=18HnU&pf_rd_p=9349ffb9-3aaa-476f-8532-6a4a5c3da3e7&pf_rd_r=AD29S7280F7DR68TFM15&qid=1614636598&sr=8-7"
  }
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
