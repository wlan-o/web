import { Component } from "@angular/core";
import { Input } from "@angular/core";

@Component({
  selector: "app-product-item",
  templateUrl: "./product-item.component.html",
  styleUrls: ["./product-item.component.css"]
})
export class ProductItemComponent {
  @Input() product;

  share_tg(url, name) {
    let tg_url = "https://t.me/share/url?url=" + url + "&text=" + name;
    window.open(tg_url, "_blank");
  }
  onNotify() {
    window.alert("You will be notified when the product goes on sale");
  }
}
