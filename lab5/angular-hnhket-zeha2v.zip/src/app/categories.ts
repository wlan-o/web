export const categories = {
  "TV":"TV",
  "IPad":"IPad",
  "Gaming":"Gaming",
  "Other":"Other"
}
// как сделать enum?