export const products = [
  {
    id: 1,
    category: "IPad",
    name:
      "New Apple iPad Air (10.9-inch, Wi-Fi, 64GB) - Sky Blue (Latest Model, 4th Generation)",
    price: 899,
    description:
      "A versatile device for comfortable work, easy content viewing and content creation",
    rating: 4.9,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71cI0vnaLiL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Apple-iPad-Air-10-9-inch-Wi-Fi-64GB/dp/B08J61FCVN/ref=sr_1_1?dchild=1&keywords=ipad&qid=1614630296&sr=8-1"
  },
  {
    id: 2,
    name: "Apple iPad Mini (Wi-Fi, 64GB) - Space Gray (Latest Model)",
    category: "IPad",
    price: 799,
    description:
      "A versatile device for comfortable work, easy content viewing and content creation",
    rating: 4.8,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71Ha06XS-VL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Apple-iPad-Mini-Wi-Fi-64GB/dp/B07PRD2NQ7/ref=sr_1_2?dchild=1&keywords=ipad&qid=1614630296&sr=8-2"
  },
  {
    id: 3,
    name:
      "2020 Apple iPad Pro (12.9-inch, Wi-Fi, 256GB) - Space Gray (4th Generation)",
    category: "IPad",
    price: 1299,
    description:
      "A versatile device for comfortable work, easy content viewing and content creation",
    rating: 4.9,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/81SGb5l%2BlZL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Apple-iPad-12-9-inch-Wi-Fi-256GB/dp/B0862HNWGK/ref=sr_1_3?dchild=1&keywords=ipad&qid=1614630296&sr=8-3"
  },
  {
    id: 4,
    name:
      "Apple Magic Keyboard for iPad Air (4th Generation) and iPad Pro 11-inch (2nd Generation) - US English",
    category: "IPad",
    price: 199,
    description:
      "The all-new Magic Keyboard is an amazing companion for iPad Pro",
    rating: 4.8,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71fYV0JMoYL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Magic-Keyboard-11-inch-iPad-Generation/dp/B0863BQJMS/ref=sr_1_4?dchild=1&keywords=ipad&qid=1614630296&sr=8-4"
  },
  {
    id: 5,
    name:
      "2020 Apple iPad Pro (11-inch, Wi-Fi, 256GB) - Space Gray (2nd Generation)",
    category: "IPad",
    price: 1199,
    description:
      "A versatile device for comfortable work, easy content viewing and content creation",
    rating: 4.9,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/815ztYEEwYL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Apple-iPad-11-inch-Wi-Fi-256GB/dp/B0863358NV/ref=sr_1_5?dchild=1&keywords=ipad&qid=1614630296&sr=8-5"
  },
  {
    id: 6,
    name:
      'SAMSUNG QN32Q50RAFXZA Flat 32" QLED 4K 32Q50 Series Smart TV (2019 model)',
    category: "TV",
    price: 447,
    description: "Very good TV",
    rating: 4.7,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/51NKhnjhpGL._AC_SL1024_.jpg",
    url:
      "https://www.amazon.com/SAMSUNG-QN32Q50RAFXZA-32Q50-Smart-TV2019/dp/B07W5QYD2K/ref=sr_1_7?dchild=1&field-shipping_option-bin=3242350011&pf_rd_i=16225009011&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=85a9188d-dbd5-424e-9512-339a1227d37c&pf_rd_r=AD29S7280F7DR68TFM15&pf_rd_s=merchandised-search-5&pf_rd_t=101&qid=1614634837&rnid=1266092011&s=electronics&sr=1-7"
  },
  {
    id: 7,
    name: "Monopoly Deal Card Game",
    category: "Other",
    price: 7.99,
    description:
      "New Monopoly Deal card game that is moving through Family Game Nights everywhere",
    rating: 4.8,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/91KOKqHaKpL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Hasbro-B0965-Monopoly-Deal-Card/dp/B00NQQTZCO/ref=sr_1_8?dchild=1&fst=as%3Aoff&pf_rd_i=16225014011&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=a3460e00-9eac-4cab-9814-093998a3f6d8&pf_rd_r=JXZSTCC3A4FCKXAZQRC2&pf_rd_s=merchandised-search-4&pf_rd_t=101&qid=1614635127&rnid=16225014011&s=sporting-goods&sr=1-8"
  },
  {
    id: 8,
    name: "Spalding NBA Street Outdoor Basketball",
    category: "Other",
    price: 17.99,
    description: "Basketball ball",
    rating: 4.7,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/91PlxEj64%2BL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Spalding-NBA-Street-Basketball-Official/dp/B0009VELG4/ref=sr_1_17?dchild=1&fst=as%3Aoff&pf_rd_i=16225014011&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=a3460e00-9eac-4cab-9814-093998a3f6d8&pf_rd_r=JXZSTCC3A4FCKXAZQRC2&pf_rd_s=merchandised-search-4&pf_rd_t=101&qid=1614636238&rnid=16225014011&s=sporting-goods&sr=1-17"
  },
  {
    id: 9,
    name: "Nintendo Switch - Mario Red & Blue Edition - Switch",
    category: "Gaming",
    price: 375.98,
    description: "Game console",
    rating: 4.9,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71K3XD9oosL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Nintendo-Switch-Mario-Red-Blue/dp/B08M8YQMH4/ref=lp_16225016011_1_5"
  },
  {
    id: 10,
    name:
      "AmazonBasics Low-Back Computer Task Office Desk Chair with Swivel Casters - Blue",
    category: "Other",
    price: 55.97,
    description:
      "Comfortable task and computer chair with blue contoured mesh back for support and breathability",
    rating: 4.9,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71rpJTFtMgL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/AmazonBasics-Low-Back-Computer-Chair-Blue/dp/B01D7P5NI8/ref=sr_1_7?dchild=1&keywords=amazonbasics&pd_rd_r=0a922aeb-fa4b-48f5-a1a0-8ec74d9b8b19&pd_rd_w=e0h4J&pd_rd_wg=18HnU&pf_rd_p=9349ffb9-3aaa-476f-8532-6a4a5c3da3e7&pf_rd_r=AD29S7280F7DR68TFM15&qid=1614636598&sr=8-7"
  },
  {
    id: 11,
    name:
      "Razer Kraken Tournament Edition THX 7.1 Surround Sound Gaming Headset: Retractable Noise Cancelling Mic - USB DAC",
    category: "Gaming",
    price: 69.99,
    description:
      "The #1 Best-Selling Gaming Peripherals Manufacturer in the US: Source - The NPD Group, Inc. U.S. Retail Tracking Service, Keyboards, Mice, PC Headset/Pc Microphone, Gaming Designed, based on dollar sales, 2017-2021",
    rating: 4.5,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/61dwuOuWXmL._AC_SL1440_.jpg",
    url:
      "https://www.amazon.com/Razer-Kraken-Tournament-Gel-Infused-Cushions/dp/B07G5TP4BN/ref=sr_1_13?dchild=1&keywords=gaming&qid=1614712183&sr=8-13"
  },
  {
    id: 12,
    name: "PlayStation 4 Slim 1TB Console",
    category: "Gaming",
    price: 299,
    description: "Game console",
    rating: 4.8,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/61GBTc2Z4wL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/PlayStation-4-Slim-1TB-Console/dp/B071CV8CG2/ref=pd_rhf_se_s_gcx-rhf_1?pd_rd_w=bPw20&pf_rd_p=2ae4ccb1-7034-4114-8654-5ba995870d70&pf_rd_r=CWRDVH8DZKPXPDJT1YNJ&pd_rd_r=b19645cd-9a94-49bd-8cf7-90f15bca2743&pd_rd_wg=oWCyR&pd_rd_i=B071CV8CG2&psc=1"
  },
  {
    id: 13,
    name: "Logitech G502 Lightspeed Wireless Gaming Mouse",
    category: "Gaming",
    price: 116.0,
    description:
      "Hero 25K Sensor, PowerPlay Compatible, Tunable Weights and Lightsync RGB - Black",
    rating: 4.6,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/71uNZAdQOoL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Logitech-Lightspeed-PowerPlay-Compatible-Lightsync/dp/B07L4BM851/ref=sr_1_31?dchild=1&keywords=gaming&qid=1614712527&rnid=2941120011&s=videogames&sr=1-31"
  },
  {
    id: 14,
    name: "Manhattan Black Wired Keyboard (5 ft. USB-A Cable)",
    category: "Gaming",
    price: 11.57,
    description:
      "[Full-sized Keyboard] Offers 104 keys, including navigational controls, full functions and a 10-key keypad",
    rating: 4.3,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/61FhqXdVUfL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Manhattan-104-key-Keyboard-Built-Indicator/dp/B07RQVB3HQ/ref=sr_1_10?dchild=1&keywords=keyboard&qid=1614712636&sr=8-10"
  },
  {
    id: 15,
    name: "LEGO City Passenger Train 60197 Building Kit (677 Pieces), Standard",
    category: "Other",
    price: 164.0,
    description:
      "Passenger Train locomotive with cars measures over 4-inch (11cm) high, 27-inch (69cm) long and 1-inch (5cm) wide Engine section measures over 4-inch (11cm) high, 10-inch (26cm) long and 1-inch (5cm) wide Platform measures over 2-inch (7cm) high, 4-inch (11cm) wide and 2-inch (6cm) deep",
    rating: 4.8,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/91DGvahb%2BDL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/LEGO-Passenger-Train-Building-Multicolor/dp/B07BHGHXD3/ref=sr_1_1?dchild=1&keywords=lego+train&qid=1614712982&sr=8-1"
  },
  {
    id: 16,
    name: "Super GT RC Sport Racing Drift Car, 1/16 Remote Control Car",
    category: "Other",
    price: 70.99,
    description: "Cool RC drift car",
    rating: 3.7,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/61PqHp%2BPmLL._AC_SL1200_.jpg",
    url:
      "https://www.amazon.com/Racing-Remote-Control-Vehicle-Battery/dp/B06ZYGW6H2/ref=sr_1_5?crid=30PC7VDB97NGC&dchild=1&keywords=ae86+rc+drift+car&qid=1614713169&sprefix=AE8%2Caps%2C337&sr=8-5"
  },
  {
    id: 17,
    name:
      "All-New Insignia NS-39DF310NA21 39-inch Smart HD 720p TV - Fire TV Edition",
    category: "TV",
    price: 169.99,
    description: "a TV",
    rating: 4.6,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/612LGuPnbVL._AC_SL1000_.jpg",
    url:
      "https://www.amazon.com/All-New-Insignia-NS-39DF310NA21-39-inch-Smart/dp/B0875M44Y5/ref=sr_1_5_sspa?dchild=1&keywords=tv&qid=1614713482&sr=8-5-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyWFdUODI1Skk5NkJQJmVuY3J5cHRlZElkPUExMDQ1NzkwMjJEQlE5N0RBSDVXWiZlbmNyeXB0ZWRBZElkPUEwODQ0MjA5M0FLQVlES1EzSlhEMyZ3aWRnZXROYW1lPXNwX210ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU="
  },
  {
    id: 18,
    name:
      "All-New Toshiba 32LF221U21 32-inch Smart HD 720p TV - Fire TV Edition, Released 2020",
    category: "TV",
    price: 139.99,
    description: "Another TV",
    rating: 4.7,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/61x0OuU9XtL._AC_SL1000_.jpg",
    url:
      "https://www.amazon.com/All-New-Toshiba-32LF221U21-32-inch-Smart/dp/B0872FYTWS/ref=sr_1_10_sspa?dchild=1&keywords=tv&qid=1614713482&sr=8-10-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyWFdUODI1Skk5NkJQJmVuY3J5cHRlZElkPUExMDQ1NzkwMjJEQlE5N0RBSDVXWiZlbmNyeXB0ZWRBZElkPUEwMTk1Mzg2MTExNTY1OVpEVUZKUSZ3aWRnZXROYW1lPXNwX210ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU="
  },
  {
    id: 19,
    name:
      "Leankle Universal Remote Controller for All Samsung RU7100, RU710D, RU7200, RU7300, RU730D, TU7000, TU700D Smart 4K UHD 7 Series TVs",
    category: "TV",
    price: 17.5,
    description: "A remote controller",
    rating: "--",
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/81LJmM6lKJL._AC_SL1500_.jpg",
    url:
      "https://www.amazon.com/Leankle-Universal-Remote-Controller-Samsung/dp/B08V4SJ5LS/ref=sr_1_22_sspa?dchild=1&keywords=tv&qid=1614713482&sr=8-22-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyWFdUODI1Skk5NkJQJmVuY3J5cHRlZElkPUExMDQ1NzkwMjJEQlE5N0RBSDVXWiZlbmNyeXB0ZWRBZElkPUEwMjY5OTYxMjFEOERBVlVKWkxJTSZ3aWRnZXROYW1lPXNwX2J0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU="
  },
  {
    id: 20,
    name: "VIZIO D-Series 24” 1080P Smart TV (Renewed)",
    category: "TV",
    price: 129.99,
    description: "Smart TV",
    rating: 4.1,
    likes: 0,
    img:
      "https://images-na.ssl-images-amazon.com/images/I/61apD0DBOcL._AC_SL1000_.jpg",
    url:
      "https://www.amazon.com/VIZIO-Class-Diag-Smart-Renewed/dp/B07ZZJ18VL/ref=sr_1_8?dchild=1&keywords=tv&qid=1614713781&rnid=2941120011&s=amazon-devices&sr=1-8"
  }
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
