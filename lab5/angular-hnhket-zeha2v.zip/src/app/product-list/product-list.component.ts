import { Component } from "@angular/core";
import { products } from '../products';
import { categories } from '../categories';

@Component({
  selector: "app-product-list",
  templateUrl: "./product-list.component.html",
  styleUrls: ["./product-list.component.css"]
})
export class ProductListComponent {
  categories=categories;
  products=products;
  current_category="";
  show(category){
    this.current_category=category;
  }
}

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
